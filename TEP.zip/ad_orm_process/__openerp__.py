{
    "name": "ORM Force",
    "version": "1.0",
    "depends": ["base"],
    "author": "Dedi - Adsoft",
    "category": "Technical",
    "description": """
    This Module is use to access orm through webclient
    """,
    "init_xml": [],
    'update_xml': [
                    "orm_force_view.xml",
                   ],
    'demo_xml': [],
    'installable': True,
    'active': False,
    'application':True,
}