# -*- coding: utf-8 -*-
{
    'name'      : "Totalindo Contract",
    'version'   : '1.1',
    'summary'   : 'HR Contract',
    'sequence'  : 30,
    'author'    : "Dion Martin",
    # 'website'   : "http://odooabc.com",
    'category'  : 'Human Resource',
    'depends'   : ['base','hr'],
    'data'      : [
            'views/hr_contract_view.xml',
    ],
    'demo': [
    ],
    'installable'   : True,
    'application'   : True,
    'auto_install'  : False,
}
